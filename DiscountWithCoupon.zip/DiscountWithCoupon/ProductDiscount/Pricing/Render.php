<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Kinex\ProductDiscount\Pricing;

use Magento\Framework\Pricing\Helper\Data;
use Magento\Catalog\Model\Product;
use Magento\Framework\Pricing\SaleableInterface;
use Magento\Framework\Pricing\Render as PricingRender;
use Magento\Framework\Registry;
use Magento\Framework\View\Element\Template;


/**
 * Catalog Price Render
 *
 * @api
 * @method string getPriceRender()
 * @method string getPriceTypeCode()
 * @since 100.0.2
 */
class Render extends Template
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;
    protected $dataPersistor;
    protected $priceHelper;
    /**
     * Construct
     *
     * @param Template\Context $context
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Data $priceHelper,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        Registry $registry,
        array $data = []
    ) {
        $this->registry = $registry;
        $this->priceHelper = $priceHelper;
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context, $data);
    }

    /**
     * Produce and return block's html output
     *
     * @return string
     */
    protected function _toHtml()
    {
        /** @var PricingRender $priceRender */
        $priceRender = $this->getLayout()->getBlock($this->getPriceRender());

        if ($priceRender instanceof PricingRender) {
            $product = $this->getProduct();

            
            $sku = $product->getSku();
            $finalPrice = $product->getFinalPrice();
            $originalPrice = $product->getPrice();
            
            
            if(!empty($this->dataPersistor->get('coupon_price_'. $sku) &&  $this->dataPersistor->get($sku)))
            {
                $discountAmount=$this->dataPersistor->get('coupon_price_'. $sku);
                $sessionSku=$this->dataPersistor->get($sku);
            }

           
            if ($product instanceof SaleableInterface) {
                
                if (isset($discountAmount) && isset( $sessionSku) ) {
                  
                   $customPrice= $originalPrice-$discountAmount;
                   $productOriginalPrice=$this->priceHelper->currency($originalPrice, true, false);
                  $price=
                  '<div class="price-box price-final_price" data-role="priceBox">
                  <span class="price-container price-final_price tax weee" itemprop="offers" itemscope="">
                          <span  data-price-amount="'.$productOriginalPrice.'" data-price-type="finalPrice" class="price-wrapper ">
                          <span class="price">'.$this->priceHelper->currency($customPrice, true, false).'</span></span>
                                  <meta itemprop="price" >
                          <meta itemprop="priceCurrency">
                      </span>
                  
                  </div>';


                  return $price;
                } 
                else
                {
                    $arguments = $this->getData();
                    $arguments['render_block'] = $this;
                    return $priceRender->render($this->getPriceTypeCode(), $product, $arguments);
                }
          
            
            }
        }
        return parent::_toHtml();
    }

    /**
     * Returns saleable item instance
     *
     * @return Product
     */
    protected function getProduct()
    {
        $parentBlock = $this->getParentBlock();

        $product = $parentBlock && $parentBlock->getProductItem()
            ? $parentBlock->getProductItem()
            : $this->registry->registry('product');
        return $product;
    }

    public function getCouponPrice()
    {
        $discountAmount = $this->session->getPrice();
        if(!empty($discountAmount))
        {
            return  $discountAmount['discount_amount'];
        }
        else{
            return 0;
        }
        
    }
}
