<?php
namespace Kinex\ProductDiscount\Observer;

class ChangeItemPrice implements \Magento\Framework\Event\ObserverInterface
{
    protected $helper;
    protected $logger;
    protected $_customerSession;
    public function __construct( 
        \Magento\Customer\Model\Session $customerSession,
        \Psr\Log\LoggerInterface $logger,
        \Kinex\ProductDiscount\Helper\Data $helper) {
            $this->logger = $logger; 
            $this->_customerSession = $customerSession;
        $this->helper = $helper;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        // Loop through order items and change the price as needed
        foreach ($order->getAllItems() as $item) {
            $couponCode =$this->helper->dataPersistor()->get('coupon_code_' .$item->getSku());
            if (isset($couponCode)) {
              
                
                    $coupon = $this->helper->getCouponCollection($couponCode);
                    if (!empty($coupon)) {
                        $discount = (int) $coupon[0]['discount_amount'];
                    }
                    
                    if (isset($coupon[0]['simple_action'])) {
                        if ($coupon[0]['simple_action'] == 'by_percent') {
                            $discountpercent =(int) $coupon[0]['discount_amount'];
                            $discount = ($item->getPrice()/ 100) * $discountpercent;    
                        }
                    }

                    $newPrice = $item->getPrice()- $discount;
                    $itemQty=(int)$item->getData('qty_ordered');
                    $itemSubTotal=$newPrice* $itemQty;
                    $item->setPrice($newPrice);
                    $item->setPrice($newPrice);
                    $item->setData('row_total', $itemSubTotal);
                    $item->setData('base_row_total', $itemSubTotal);
                 
                }
            $this->logger->debug(json_encode($item->getData()));
       
        }
        $order->save();
       

        
    }
}