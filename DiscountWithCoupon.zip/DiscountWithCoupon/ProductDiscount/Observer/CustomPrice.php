<?php


namespace Kinex\ProductDiscount\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;

class CustomPrice implements ObserverInterface
{
    protected $_catalogSession;
    protected $dataPersistor;
    protected $productFactory;
    protected $helper;

    public function __construct(
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Model\Session $catalogSession,
        DataPersistorInterface $dataPersistor,
        \Kinex\ProductDiscount\Helper\Data $helper
    ) {
        $this->_catalogSession = $catalogSession;
        $this->productFactory = $productFactory;
        $this->dataPersistor = $dataPersistor;
        $this->helper = $helper;
    }


    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $item = $observer->getEvent()->getData('quote_item');
        $item = ($item->getParentItem() ? $item->getParentItem() : $item);
        $originalPrice = $item->getPrice();
        $productFinalPrice=$this->getPriceById($item->getProductId());
        $couponCode=$this->dataPersistor->get('coupon_code_'.$item->getSku());
        if (isset($couponCode)) {
            $coupon = $this->helper->getCouponCollection($couponCode);
            $discountPrice = $coupon[0]['discount_amount'];
        }
        if(!empty($discountPrice))
        {
            $this->dataPersistor->set('coupon_code_' .$item->getQuoteId(),$couponCode);
            $discount_amount=$this->dataPersistor->get('%_discount_amount_' . $item->getSku());
            if(!empty( $discount_amount))
            {
                $this->dataPersistor->set('%_discount_amount_' . $item->getQuoteId(), $discount_amount);
            }
            $item->setBasePrice($originalPrice);
            $item->setData('product_discount',1);
            $item->setCustomPrice($originalPrice);
          
        }     
    }

    public function dataPersistor()
    {
        return $this->dataPersistor;
    }

    public function getPriceById($id)
    {
        
        $product = $this->productFactory->create();
        $productPriceById = $product->load($id)->getPrice();
        return $productPriceById;
    }
}
