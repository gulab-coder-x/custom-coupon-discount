<?php

namespace Kinex\ProductDiscount\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Sales\Model\Order\Item as OrderItem;

class  SalesOrderItemSaveAfter implements ObserverInterface
{

    protected $helper;
    protected $logger;
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Kinex\ProductDiscount\Helper\Data $helper
    ) {
        $this->logger = $logger;
        $this->helper = $helper;
    }
    public function execute(Observer $observer)
    {
        /** @var OrderItem $orderItem */
        $orderItem = $observer->getEvent()->getItem();
        //$this->logger->debug( $result);
        $couponCode = $this->helper->dataPersistor()->get('coupon_code_' . $orderItem->getSku());
        if (isset($couponCode)) {
            $checkoutSession = $this->helper->getObjectManager()->get('\Magento\Checkout\Model\Session');
            $getQuoteId = (int)$checkoutSession->getQuote()->getId();
            $this->helper->dataPersistor()->clear('coupon_code_' . $getQuoteId);
            $this->helper->dataPersistor()->clear('%_discount_amount_' . $getQuoteId);
            $this->helper->dataPersistor()->clear('coupon_code_' .  $orderItem->getSku());
            $this->helper->dataPersistor()->clear('product_price_' .  $orderItem->getSku());
            $this->helper->dataPersistor()->clear($orderItem->getSku());
        }
        $orderItem->save();
    }
}
