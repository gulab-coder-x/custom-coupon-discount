<?php
namespace Kinex\ProductDiscount\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
   public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
   {
       $setup->startSetup();

       $setup->getConnection()->addColumn(
        $setup->getTable('catalog_product_entity'),
        'product_discount',
        [
            'type'     => Table::TYPE_BOOLEAN,
            'unsigned' => true,
            'nullable' => false,
            'default'  => '0',
            'comment' => 'Product Discount'
        ]
       );
       $setup->getConnection()->addColumn(
        $setup->getTable('quote_item'),
        'product_discount',
        [
            'type'     => Table::TYPE_BOOLEAN,
            'unsigned' => true,
            'nullable' => false,
            'default'  => '0',
            'comment' => 'Product Discount'
        ]
       );
       $setup->endSetup();
   }
}
