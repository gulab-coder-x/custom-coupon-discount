<?php
namespace  Kinex\ProductDiscount\Model\ResourceModel\ProductRule;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'product_rule_id';
    /**
     * Define resource model.
     */
    protected function _construct()
    {
        $this->_init('Kinex\ProductDiscount\Model\ProductRule', 'Kinex\ProductDiscount\Model\ResourceModel\ProductRule');
    }
}
