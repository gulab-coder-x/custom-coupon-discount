<?php

namespace Kinex\ProductDiscount\Model\Creditmemo\Total;

use Magento\Sales\Model\Order\Creditmemo\Total\AbstractTotal;

class Discount extends AbstractTotal
{
    /**
     * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
     * @return $this
     */
    protected $orderFactory;
     protected $dataPersistor;
     public function __construct(
        \Magento\Sales\Model\OrderFactory $orderFactory,
         \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
     ) {
         $this->dataPersistor = $dataPersistor;
         $this->orderFactory= $orderFactory;
     }
    public function collect(\Magento\Sales\Model\Order\Creditmemo $creditmemo)
    {
        $order = $this->orderFactory->create()->load($creditmemo->getOrderId());
        $customDiscountAmount=(int)abs($order->getData('base_discount_amount'));
        $creditmemo->setGrandTotal($creditmemo->getGrandTotal());
        $creditmemo->setBaseGrandTotal($creditmemo->getBaseGrandTotal());
        return $this;
    }

}
