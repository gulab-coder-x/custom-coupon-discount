<?php

namespace Kinex\ProductDiscount\Model\Invoice\Total;
use Magento\Sales\Model\Order\InvoiceFactory;
use Magento\Sales\Model\OrderFactory;


use Magento\Sales\Model\Order\Invoice\Total\AbstractTotal;

class Discount extends AbstractTotal
{
    /**
     * @param \Magento\Sales\Model\Order\Invoice $invoice
     * @return $this
     */
    protected $helperData;
     protected $_catalogSession;
     protected $orderFactory;
     /**
      * @param \Magento\Framework\Event\ManagerInterface $eventManager
      * @param \Magento\Store\Model\StoreManagerInterface $storeManager
      * @param \Magento\SalesRule\Model\Validator $validator
      * @param \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency
      */
     public function __construct(
         \Magento\Catalog\Model\Session $catalogSession,
         \Kinex\ProductDiscount\Helper\Data $helper,
         \Magento\Sales\Model\OrderFactory $orderFactory
         
     ) {
        $this->helper = $helper;
         $this->_catalogSession = $catalogSession;
         $this->orderFactory= $orderFactory;
     }
 

    public function collect(\Magento\Sales\Model\Order\Invoice $invoice)
    {
        $order = $this->orderFactory->create()->load($invoice->getOrderId());
        $customDiscountAmount=(int)abs($order->getData('base_discount_amount'));
        $invoice->setGrandTotal($invoice->getGrandTotal() - $customDiscountAmount);
        $invoice->setBaseGrandTotal($invoice->getBaseGrandTotal() - $customDiscountAmount);
        return $this;
    }


    

}


