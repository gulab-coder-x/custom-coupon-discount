<?php
namespace Kinex\ProductDiscount\Model;
use Kinex\ProductDiscount\Api\Data\ProductRuleInterface;

class ProductRule extends \Magento\Framework\Model\AbstractModel  implements ProductRuleInterface
{
        const CACHE_TAG = 'product_rule';
        const STATUS_ENABLED = 1;
        const STATUS_DISABLED = 0;
  
        protected $_cacheTag = 'product_rule';
        protected $_eventPrefix = 'product_rule';

    protected function _construct()
    {
        $this->_init('Kinex\ProductDiscount\Model\ResourceModel\ProductRule');
    }
  

    public function getIdentities()
    {
            return [self::CACHE_TAG . '_' . $this->getId()];
    }

    public function getDefaultValues()
    {
            $values = [];

            return $values;
    }


    public function getProductRuleId()
    {
            return parent::getData(self::PRODUCT_RULE_ID);
    }

    public function getRuleNameId()
    {
        return parent::getData(self::RULE_NAME_ID);
    }
    
    public function setRuleNameId($ruleNameId)
    {
        return parent::getData(self::RULE_NAME_ID,$ruleNameId);
    }

    public function getProductRuleName()
    {
            return parent::getData(self::PRODUCT_RULE_NAME);
    }  

    
    public function setProductRuleName($productRuleName)
    {
            return $this->getData(self::PRODUCT_RULE_NAME,$productRuleName);
    }

    public function getStatus()
    {
            return parent::getData(self::STATUS);
    }  

    public function setStatus($status)
    {
            return $this->getData(self::STATUS,$status);
    }
    public function getAvailableStatuses()
    {
        return[self::STATUS_ENABLED => __('Enabled'),self::STATUS_DISABLED => __('Disabled')];
    }
    public function getCouponCode()
    {
            return parent::getData(self::COUPON_CODE);
    }  

    public function setCouponCode($couponCode)
    {
            return $this->getData(self::COUPON_CODE,$couponCode);
    }

    public function getFromDate()
    {
            return parent::getData(self::FROM_DATE);
    }  

    public function setFromDate($fromDate)
    {
            return $this->getData(self::FROM_DATE,$fromDate);
    }


    public function getSimpleAction()
    {
        return $this->getData(self::SIMPLE_ACTION);
    }

  
    public function setSimpleAction($action)
    {
        return $this->setData(self::SIMPLE_ACTION, $action);
    }

    public function getDiscountAmount()
    {
        return $this->getData(self::DISCOUNT_AMOUNT);
    }

    public function setDiscountAmount($amount)
    {
        return $this->setData(self::DISCOUNT_AMOUNT, $amount);
    }

    public function getToDate()
    {
            return parent::getData(self::TO_DATE);
    }  

    public function setToDate($toDate)
    {
            return $this->getData(self::TO_DATE,$toDate);
    }

    public function getCategory()
    {
        return $this->getData(self::CATEGORY);
    }

    public function setCategory($category)
    {
        return $this->setData(self::CATEGORY, $category);
    }

    public function getCouponUseLimit()
    {
        return $this->getData(self::COUPON_USE_LIMIT);
    }

    public function setCouponUseLimit($limit)
    {
        return $this->getData(self::COUPON_USE_LIMIT);
    }
}