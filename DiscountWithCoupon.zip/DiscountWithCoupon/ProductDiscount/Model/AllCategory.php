<?php
namespace Kinex\ProductDiscount\Model;
use Magento\Framework\Data\OptionSourceInterface;
class AllCategory implements OptionSourceInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        $options = [];

        // Load options from your custom logic or source
        $options[] = ['value' => 'option1', 'label' => __('Option 1')];
        $options[] = ['value' => 'option2', 'label' => __('Option 2')];
        // Add more options as needed

        return $options;
    }
}

