<?php

/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Kinex\ProductDiscount\Model\Quote;

class Discount extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
    /**
     * Discount calculation object
     *
     * @var \Magento\SalesRule\Model\Validator
     */
    protected $calculator;

    /**
     * Core event manager proxy
     *
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $eventManager = null;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\Pricing\PriceCurrencyInterface
     */
    protected $priceCurrency;

    protected $session;
    protected $helperData;
    protected $dataPersistor;
    protected $productRuleFactory;
    protected $_checkoutSession;
    protected $helper;
    protected $logger;
    public function __construct(
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\SalesRule\Model\Validator $validator,
        \Magento\Framework\Pricing\PriceCurrencyInterface $priceCurrency,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Kinex\ProductDiscount\Helper\Data $helper,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Psr\Log\LoggerInterface $logger,
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->setCode('custom_product_discount');
        $this->eventManager = $eventManager;
        $this->calculator = $validator;
        $this->storeManager = $storeManager;
        $this->helper = $helper;
        $this->logger = $logger;
        $this->dataPersistor = $dataPersistor;
        $this->priceCurrency = $priceCurrency;
    }

    public function collect(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);
        $address             = $shippingAssignment->getShipping()->getAddress();
        $label               = '';
        if (!empty($this->dataPersistor()->get('coupon_code_' . $quote->getEntityId()))) {
           
            $couponCode = $this->dataPersistor()->get('coupon_code_' . $quote->getEntityId());
            $label =$couponCode ; 
            $coupon = $this->helper->getCouponCollection($couponCode);
            $discount_amount = $this->dataPersistor->get('%_discount_amount_' . $quote->getEntityId());

            $productQty = [];
            $productId='';
            foreach ($quote->getAllVisibleItems() as $_item) {
                
                if ($_item->getData('product_discount') == 1) {
                    $productQty[] = (int)$_item->getQty();
                   $productId=$_item->getProductId();
                }
            }
          $product= $this->helper->getProduct($productId);
          
          if(isset($product))
          {
            $result =(int)$product->getData('price');
          }
            $qty = array_sum($productQty);
            if ($qty == 0) {
                $qty = (int)$quote->getData('items_qty');
            }
           
            if ($coupon[0]['simple_action'] == 'by_percent') {
            
                $discountpercent = $coupon[0]['discount_amount'];
                $discount = ($result / 100) * $discountpercent;
                $discount_amount=(int)    $discount ;
            }
            else
            {
               $discount_amount=(int)-$coupon[0]['discount_amount'];
            }
            if ($discount_amount) {
                $discountAmount   = $discount_amount;

            } else {
                $discountAmount   = $discount_amount;
            }
            $discountAmount2=0;
            if ($discountAmount) {

                $discountAmount2 = abs($discountAmount) * $qty;
            }
            $total->setDiscountDescription($label);
            $total->setDiscountAmount(-$discountAmount2);
            $total->setBaseDiscountAmount(-$discountAmount2);
            // $total->setSubtotalWithDiscount($quote->getSubtotal());
            $total->addTotalAmount($this->getCode(), -$discountAmount2);
            $total->addBaseTotalAmount($this->getCode(), -$discountAmount2);
        }


        return $this;
    }



    /**
     * Add discount total information to address
     *
     * @param \Magento\Quote\Model\Quote $quote
     * @param \Magento\Quote\Model\Quote\Address\Total $total
     * @return array|null
     */


    public function fetch(\Magento\Quote\Model\Quote $quote, \Magento\Quote\Model\Quote\Address\Total $total)
    {
        $result = null;
        $amount = $total->getDiscountAmount();

        // ONLY return 1 discount. Need to append existing
        //see app/code/Magento/Quote/Model/Quote/Address.php

        if ($amount != 0) {
            $description = $total->getDiscountDescription();
            $result = [
                'code' => $this->getCode(),
                'title' => strlen($description) ? __('Discount (%1)', $description) : __('Discount'),
                'value' => $amount
            ];
        }
        return $result;


        /* in magento 1.x
           $address->addTotal(array(
                'code' => $this->getCode(),
                'title' => $title,
                'value' => $amount
            ));
         */
    }

    public function dataPersistor()
    {
        return $this->dataPersistor;
    }
}
