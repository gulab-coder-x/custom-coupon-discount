<?php
namespace Kinex\ProductDiscount\Model;

use Kinex\ProductDiscount\Api\Data;
use Kinex\ProductDiscount\Api\ProductRuleRepositoryInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Kinex\ProductDiscount\Model\ResourceModel\ProductRule as ResourceProductRule;
use Kinex\ProductDiscount\Model\ResourceModel\ProductRule\CollectionFactory as ProductRuleCollectionFactory;
use Magento\Store\Model\StoreManagerInterface;

class ProductRuleRepository implements ProductRuleRepositoryInterface
{
    protected $resource;

    protected $productRuleFactory;

    protected $dataObjectHelper;

    protected $dataObjectProcessor;

    protected $dataContactusFactory;

    private $storeManager;

    public function __construct(
        ResourceProductRule $resource,
        ProductRuleFactory $productRuleFactory,
        Data\ProductRuleInterfaceFactory $dataContactusFactory,
        DataObjectHelper $dataObjectHelper,
		DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager
    ) {
        $this->resource = $resource;
		$this->productRuleFactory = $productRuleFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataContactusFactory = $dataContactusFactory;
		$this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
    }

    public function save(\Kinex\ProductDiscount\Api\Data\ProductRuleInterface $productRule)
    {
        if ($productRule->getStoreId() === null) {
            $storeId = $this->storeManager->getStore()->getId();
            $productRule->setStoreId($storeId);
        }
        try {
            $this->resource->save($productRule);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(
                __('Could not save the Product Rule : %1', $exception->getMessage()),
                $exception
            );
        }
        return $productRule;
    }

    public function getById($productRuleId)
    {
		$productRule = $this->productRuleFactory->create();
        $productRule->load($productRuleId);
        if (!$productRule->getId()) {
            throw new NoSuchEntityException(__('Rule with id "%1" does not exist.', $productRuleId));
        }
        return $productRule;
    }
	
    public function delete(\Kinex\ProductDiscount\Api\Data\ProductRuleInterface $productRule)
    {
        try {
            $this->resource->delete($productRule);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Product Rule: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    public function deleteById($productRuleId)
    {
        return $this->delete($this->getById($productRuleId));
    }
}