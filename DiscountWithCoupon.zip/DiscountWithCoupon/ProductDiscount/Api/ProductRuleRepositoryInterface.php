<?php
 namespace Kinex\ProductDiscount\Api;
 interface ProductRuleRepositoryInterface 
 {
    public function save(\Kinex\ProductDiscount\Api\Data\ProductRuleInterface $productRule);

    public function getById($productRuleId);

    public function delete(\Kinex\ProductDiscount\Api\Data\ProductRuleInterface $productRule);

    public function deleteById($productRuleId);
 }
?>

