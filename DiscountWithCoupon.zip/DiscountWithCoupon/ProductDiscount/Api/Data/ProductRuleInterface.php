<?php
namespace Kinex\ProductDiscount\Api\Data;

interface ProductRuleInterface
{
    const PRODUCT_RULE_ID = 'product_rule_id';
    const RULE_NAME_ID ='rule_name_id';
    const PRODUCT_RULE_NAME ='product_rule_name';
    const STATUS ='status';
    const COUPON_CODE ='coupon_code';
    const FROM_DATE = 'from_date';
    const TO_DATE ='to_date';
    const SIMPLE_ACTION = 'simple_action';
    const DISCOUNT_AMOUNT = 'discount_amount';
    const CREATED_AT ='created_at';
    const UPDATED_AT ='updated_at';
    const CATEGORY ='category';
    const COUPON_USE_LIMIT='coupon_use_limit';
    

    public function getProductRuleId();

    public function getRuleNameId();
    
    public function setRuleNameId($ruleNameId);

    public function getProductRuleName();
    
    public function setProductRuleName($productRuleName);

    public function getStatus();

    public function setStatus($status);
  
    public function getCouponCode();

    public function setCouponCode($couponCode);
    
    public function getFromDate();

    public function setFromDate($fromDate);
  
    public function getToDate();

    public function setToDate($toDate);

    public function getSimpleAction();

    public function setSimpleAction($action);

    public function getDiscountAmount();
    public function setDiscountAmount($amount);

    public function getCategory();
    public function setCategory($category);

    public function getCouponUseLimit();
    public function setCouponUseLimit($limit);

    
}