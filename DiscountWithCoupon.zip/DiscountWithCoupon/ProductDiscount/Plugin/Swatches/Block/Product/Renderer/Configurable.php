<?php
namespace Kinex\ProductDiscount\Plugin\Swatches\Block\Product\Renderer;
 
class Configurable
{
    public function afterGetJsonConfig(\Magento\Swatches\Block\Product\Renderer\Configurable $subject, $result) {
 
        $jsonResult = json_decode($result, true);
        $jsonResult['skus'] = [];
        $jsonResult['names'] = [];
        $jsonResult['ids'] = [];
 
        foreach ($subject->getAllowProducts() as $simpleProduct) {
           $jsonResult['skus'][$simpleProduct->getId()] = $simpleProduct->getSku();
           $jsonResult['names'][$simpleProduct->getId()] = $simpleProduct->getName();
           $jsonResult['ids'][$simpleProduct->getId()] = $simpleProduct->getId();
        }
        $result = json_encode($jsonResult);
        return $result;
	}
}