<?php

namespace Kinex\ProductDiscount\Plugin\Model;

use Magento\Framework\App\Area;
use Magento\Framework\App\State;

class Category
{
    /**
     * @var State
     */
    private $state;
    protected $dataPersistor;
    protected $helper;

    public function __construct(
        State $state,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Kinex\ProductDiscount\Helper\Data $helper
    ) {
        $this->state = $state;
        $this->helper = $helper;
        $this->dataPersistor = $dataPersistor;
    }

    public function afterGetPrice(\Magento\Catalog\Model\Product $subject, $result)
    {
        $tierPrice=$subject->getPriceInfo()->getPrice('special_price')->getValue();
        $specialPrice=0;
        if($tierPrice)
        {
           $specialPrice= $result-$tierPrice;
        }
        if ($this->state->getAreaCode() === Area::AREA_FRONTEND) {
            $productSku = $this->dataPersistor->get($subject->getSku());
            $couponCode = $this->dataPersistor->get('coupon_code_' . $productSku);
            if (isset($couponCode)) {
                $coupon = $this->helper->getCouponCollection($couponCode);
            }

            if (!empty($coupon)) {
                $discount =  $coupon[0]['discount_amount'];
            }

            if (isset($coupon[0]['simple_action'])) {
                if ($coupon[0]['simple_action'] == 'by_percent') {
                    $discountpercent = $coupon[0]['discount_amount'];
                    $discount = ($result / 100) * $discountpercent;
                    $this->dataPersistor->set('%_discount_amount_' . $subject->getSku(), $discount);
                }


                if ($productSku) {
                    $result -=  $discount+$specialPrice;
                }
            }

            return $result;
        }
    }
}
