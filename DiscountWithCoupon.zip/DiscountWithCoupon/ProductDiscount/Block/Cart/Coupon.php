<?php

/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Kinex\ProductDiscount\Block\Cart;
use Magento\Framework\Registry;
use Magento\Captcha\Block\Captcha;
use Magento\Framework\App\Request\DataPersistorInterface;


class Coupon extends \Magento\Framework\View\Element\Template
{

    protected $_productRuleFactory;
    protected $registry;
    protected $dataPersistor;
    protected $_checkoutSession;
    protected $_catalogSession;
    protected $helper;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Kinex\ProductDiscount\Model\ProductRuleFactory $productRuleFactory,
        \Kinex\ProductDiscount\Helper\Data $helper,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Catalog\Model\Session $catalogSession,
        DataPersistorInterface $dataPersistor,
        Registry $registry,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_productRuleFactory = $productRuleFactory;
        $this->_catalogSession = $catalogSession;
        $this->helper= $helper;
        $this->registry = $registry;
        $this->dataPersistor = $dataPersistor;
        $this->_checkoutSession = $checkoutSession;
    }

    public function getHelper()
    {
        return $this->helper;
    }
    public function getCouponCode()
    {
        $collection = $this->_productRuleFactory->create()->getCollection();
        $collection->addFieldToFilter('status', 1)
            ->addFieldToSelect('coupon_code');
        return $collection->getData('coupon_code');
    }
    public function getCollection()
    {
        $collection = $this->_productRuleFactory->create()->getCollection();
        $collection->addFieldToFilter('status', 1)
            ->addFieldToSelect('*');
        return $collection;
    }
    public function getDiscount()
    {
        $price = $this->getCollection()->getData('discount_amount');
        return $price[0]['discount_amount'];
    }

    public function getCategory()
    {
        $category = $this->getCollection()->getData('category');
        return $category[0]['category'];
    }
    public function getDiscountType()
    {
        $price = $this->getCollection()->getData('simple_action');
        return $price[0]['simple_action'];
    }


    public function getDataPersister()
    {
        return $this->dataPersistor;
    }

    public function getCurrentCategory()
    {
        return $this->registry->registry('current_category');
    }

    /**
     * @inheritDoc
     * @since 100.3.2
     */
    protected function _prepareLayout()
    {
        if (!$this->getChildBlock('captcha')) {
            $this->addChild(
                'captcha',
                Captcha::class,
                [
                    'cacheable' => false,
                    'after' => '-',
                    'form_id' => 'sales_rule_coupon_request',
                    'image_width' => 230,
                    'image_height' => 230
                ]
            );
        }

        return parent::_prepareLayout();
    }
}
