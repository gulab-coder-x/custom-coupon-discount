<?php
namespace Kinex\ProductDiscount\Block;

class ProductInfo extends \Magento\Framework\View\Element\Template
{
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
    */
    protected $helper;
    protected $itemRendrar;
    public function __construct(
        \Kinex\ProductDiscount\Helper\Data $helper,
        \Magento\Checkout\Block\Cart\Item\Renderer $itemRendrar,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->helper= $helper;
        $this->itemRendrar=$itemRendrar;
    }
    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
    }
    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        parent::_prepareLayout();
    }
    /**
     * @return additional information data
     */
    public function getAdditionalData()
    {
        // Do your code here
        return "Additional Informations";
    }

    public function couponHelper()
    {
        return   $this->helper;
    }


    public function itemRendrar()
    {
        return $this->itemRendrar;
    }
}