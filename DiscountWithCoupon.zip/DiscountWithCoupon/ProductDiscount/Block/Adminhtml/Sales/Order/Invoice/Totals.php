<?php

namespace Kinex\ProductDiscount\Block\Adminhtml\Sales\Order\Invoice;

class Totals extends \Magento\Framework\View\Element\Template
{

    /**
     * @var \Kinex\Extrafee\Helper\Data
     */
    protected $_dataHelper;

    /**
     * Order invoice
     *
     * @var \Magento\Sales\Model\Order\Invoice|null
     */
    protected $_invoice = null;

    /**
     * @var \Magento\Framework\DataObject
     */
    protected $_source;

    protected $orderRepository;
    protected $_catalogSession;
    protected $dataPersistor;
    /**
     * OrderFee constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magento\Sales\Model\OrderRepository $orderRepository,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->dataPersistor = $dataPersistor;
        $this->orderRepository = $orderRepository;
    }

    /**
     * Get data (totals) source model
     *
     * @return \Magento\Framework\DataObject
     */
    public function getSource()
    {
        return $this->getParentBlock()->getSource();
    }

    public function getInvoice()
    {
        return $this->getParentBlock()->getInvoice();
    }


    public function initTotals()
    {

        $orderId = $this->getSource()->getData('order_id');
        $order = $this->orderRepository->get($orderId);
        $this->getParentBlock();
        $this->getInvoice();
        $this->getSource();

        $total = new \Magento\Framework\DataObject(
            [
                'code' => 'custom_product_discount',
                'value' => $order->getDiscountAmount(),
                'label' => 'Product Discount',
            ]
        );
        if ($order->getDiscountAmount()!=0) {
            $this->getParentBlock()->addTotalBefore($total, 'grand_total');
        }
       
        return $this;
    }
}
