<?php

namespace Kinex\ProductDiscount\Block\Adminhtml\Sales\Order\Creditmemo;

class Totals extends \Magento\Framework\View\Element\Template
{
    /**
     * Order invoice
     *
     * @var \Magento\Sales\Model\Order\Creditmemo|null
     */
    protected $_creditmemo = null;

    /**
     * @var \Magento\Framework\DataObject
     */
    protected $_source;



    protected $orderRepository;

    /**
     * OrderFee constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Sales\Model\OrderRepository $orderRepository,
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->orderRepository = $orderRepository;
   
    }


    /**
     * Get data (totals) source model
     *
     * @return \Magento\Framework\DataObject
     */
    public function getSource()
    {
        return $this->getParentBlock()->getSource();
    }

    public function getCreditmemo()
    {
        return $this->getParentBlock()->getCreditmemo();
    }


    /**
     * Initialize payment fee totals
     *
     * @return $this
     */
    public function initTotals()
    {
        $orderId = $this->getSource()->getData('order_id');
        $order = $this->orderRepository->get($orderId);
        $this->getParentBlock();
        $this->getCreditmemo();
        $this->getSource();

        $total = new \Magento\Framework\DataObject(
            [
                'code' => 'custom_product_discount',
                'strong' => false,
                'value' =>  $order->getDiscountAmount(),
                'label' => 'Product Discount',
            ]
        );

        if ($order->getDiscountAmount()!=0) {
            $this->getParentBlock()->addTotalBefore($total, 'grand_total');
        }
        return $this;
    }
}
