<?php

namespace Kinex\ProductDiscount\Block\Adminhtml\Category\Catalog\Edit\Tab;

class Conditions extends \Magento\Backend\Block\Template
{
    protected $allCategory;
    /**
     * Block template.
     *
     * @var string
     */
    protected $_template = 'category.phtml';

    /**
     * AssignProducts constructor.
     *
     * @param \Magento\Backend\Block\Template\Context  $context
     * @param array                                    $data
     */
    public function __construct(
        \Kinex\ProductDiscount\Model\AllCategory $allCategory,
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->allCategory=$allCategory;
    }

    public function getAllCategory()
    {
        return $this->allCategory;
    }
}
