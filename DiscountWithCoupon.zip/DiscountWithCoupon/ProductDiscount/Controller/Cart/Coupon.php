<?php

namespace Kinex\ProductDiscount\Controller\Cart;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class Coupon extends Action
{
    protected $_productRepository;
    protected $_resultJsonFactory;
    protected $dataPersistor;
    protected $helper;
    public function __construct(
        \Kinex\ProductDiscount\Helper\Data $helper,
        Context $context,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
    ) {
        $this->_productRepository = $productRepository;
        $this->dataPersistor = $dataPersistor;
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->helper= $helper;
        parent::__construct($context);
    }

    public function execute()
    {
        
        $result = $this->_resultJsonFactory->create();
        $couponCode = $this->getRequest()->getParam('coupon_code');  
        $id = $this->getRequest()->getParam('product_id'); 
        $response = array(
            'productPrice' => '',
            'customDiscount'=>'',
            'couponCategory'=>'',
            'itemDiscount'=>''
        );
        $coupon =$this->helper->getCouponCollection($couponCode);
     
        if($this->helper->getCouponCollection($couponCode))
        {
            $coupon =$this->helper->getCouponCollection($couponCode);
            $product=$this->helper->getProduct($id);
            $discountType = $coupon[0]['simple_action'];
           
            $couponPrice = $coupon[0]['discount_amount'];
           

            if (!empty($coupon[0]['category'])) {
               
            $product=$this->helper->getProduct($id);
                $couponCategory = $coupon[0]['category'];
                $category = $this->helper->getCategory($couponCategory);
            
                if ($category->getChildrenCategories()) {
                    $productCollectionFactory = $this->helper->getObjectManager()->get('Magento\Catalog\Model\ResourceModel\Product\CollectionFactory');
            
                    $childCategories = $category->getChildrenCategories();
                    $allChildProducts = [];
            
                    foreach ($childCategories as $childCategory) {
                        $childCategoryProducts = $productCollectionFactory->create()
                            ->addCategoryFilter($childCategory)
                            ->addAttributeToSelect('*'); // You can specify which attributes to select
            
                        foreach ($childCategoryProducts as $childItem) {
                            $allChildProducts[] = $childItem->getData('entity_id');
                        }
                    }
            
                    $key = array_search($product->getId(), $allChildProducts);
                    if ($key) {
                        $itemDiscount = 'true';
                    }
                } else {
                    $categoryProducts = $this->helper->getProductCollectionByCategories($couponCategory);
                    foreach ($categoryProducts as $item) {
                        if ($item->getId() == $product->getId()) {
                            $itemDiscount = 'true';
                        }
                    }
                }
            } else {
                $couponCategory = 0;
            }

            $response['couponCategory'] =$couponCategory;
            if(isset($itemDiscount))
            {
                $response['itemDiscount'] =$itemDiscount;
            }
          
            if ($product->getTypeId() == \Magento\ConfigurableProduct\Model\Product\Type\Configurable::TYPE_CODE) {
                $children = $product
                    ->getTypeInstance()
                    ->getUsedProducts($product);
                foreach ($children as $child) {
                    $childObj = $child;
                    $regularPrice = $child->getPriceInfo()->getPrice('regular_price')->getValue();
                    $finalPrice = $child->getFinalPrice();
                    break;
                }
                $productPrice= (int)$regularPrice;
            }
            else
            {
                $productPrice=(int)$product->getPrice();
            }

              
            if ($discountType == 'by_percent') {
                $discountpercent = (int)$couponPrice;
             
                $customDiscount =($productPrice/100)* $discountpercent;

            } else { 
                $customDiscount = (int)  $couponPrice;
            }
          
        
            $response['customDiscount'] =$customDiscount;

        }
       
        $result->setData($response);
        return $result;
    }
}
