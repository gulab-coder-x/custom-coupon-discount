<?php

namespace Kinex\ProductDiscount\Controller\Cart;

use Magento\Quote\Model\QuoteFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Customer\Model\Session as CustomerSession;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\UrlInterface;

class Index extends Action
{
    protected $_productCollectionFactory;
    protected $customerSession;
    protected $_resultPageFactory;
    protected $quoteModelFactory;
    protected $itemModel;
    protected $cart;
    protected $formKey;
    protected $quoteFactory;
    protected $productFactory;
    protected $_checkoutSession;
    protected $_catalogSession;
    protected $productRuleFactory;
    protected $_resultJsonFactory;
    protected $_cacheTypeList;
    protected $_cacheFrontendPool;
    protected $dataPersistor;
    protected $productrepository;
    protected $urlBuilder;
    protected $registry;

    public function __construct(
        \Magento\Quote\Api\CartRepositoryInterface $quoteFactory,
        \Magento\Framework\Data\Form\FormKey $formKey,
        Context $context,
        \Kinex\ProductDiscount\Model\ResourceModel\ProductRule\CollectionFactory $productRuleFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Checkout\Model\Cart $cart,
        QuoteFactory $quoteModelFactory,
        DataPersistorInterface $dataPersistor,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Model\Session $catalogSession,
        \Magento\Quote\Model\Quote\Item $itemModel,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Cache\Frontend\Pool $cacheFrontendPool,
        PageFactory $resultPageFactory,
        JsonFactory $resultJsonFactory,
        \Magento\Catalog\Api\ProductRepositoryInterface $productrepository,
        CustomerSession $customerSession,
        UrlInterface $urlBuilder
    ) {
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->customerSession = $customerSession;
        $this->quoteFactory = $quoteFactory;
        $this->formKey = $formKey;
        $this->cart = $cart;
        $this->quoteModelFactory = $quoteModelFactory;
        $this->productrepository = $productrepository;
        $this->_resultPageFactory = $resultPageFactory;
        $this->productFactory = $productFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->_catalogSession = $catalogSession;
        $this->dataPersistor = $dataPersistor;
        $this->productRuleFactory = $productRuleFactory;
        $this->_resultJsonFactory = $resultJsonFactory;
        $this->_cacheTypeList = $cacheTypeList;
        $this->_cacheFrontendPool = $cacheFrontendPool;
        $this->itemModel = $itemModel;
        $this->urlBuilder = $urlBuilder;
        $this->registry = $registry;

        parent::__construct($context);
    }

    public function execute()
    {

        $productSku = $this->getRequest()->getParam('product_sku');
        $categoryId = $this->getRequest()->getParam('product_categoryId');
        if ($productSku) {
            $this->productrepository->get($productSku);
        }
        $productId = $this->getRequest()->getParam('product_id');
        $originalPrice = $this->getRequest()->getParam('originalPrice');
        $result = $this->_resultJsonFactory->create();
        $resultPage = $this->_resultPageFactory->create();
        $response = array(
            'success' => '',
            'cancel' => '',
            'error' => '',
            'update_items' => '',
            'item_id' => '',
            'item_qty' => '',
            'discount_value' => ''
        );
        if ($this->getRequest()->getParam('remove_coupon')) {
            $couponCode = $this->getRequest()->getParam('coupon_code');
            $removeCouponCode = $this->getRequest()->getParam('remove_coupon');

            $this->customerSession->setRemoveProductFromMiniCart($productId);
            $productInfo = $this->cart->getQuote()->getItemsCollection();
            foreach ($productInfo as $item) {
                if ($item->getProductId() == $productId) {
                    $response['update_items'] = 'true';
                    $response['item_id'] = $item->getData('item_id');
                    $response['item_qty'] = $item->getData('qty');
                }
            }
            if ($removeCouponCode == '1') {
                // $categoryProducts = $this->getCategoryCollection($categoryId);
                // foreach ($categoryProducts as $product) {
                //     $this->dataPersistor->clear('coupon_code_' . $this->getQuoteId());
                //     $this->dataPersistor->clear('%_discount_amount_' . $this->getQuoteId());
                //     $this->dataPersistor->clear('coupon_code_' .  $product->getSku());
                //     $this->dataPersistor->clear($product->getSku());
                // }
                $product = $this->getProductDataUsingSku($productSku);
                if ($product->getTypeId() == \Magento\ConfigurableProduct\Model\Product\Type\Configurable::TYPE_CODE) {
                    $_children = $product->getTypeInstance()->getUsedProducts($product);
                    foreach ($_children as $child) {
                        $this->dataPersistor->clear('coupon_code_' . $child->getSku());
                        $this->dataPersistor->clear('product_price_' . $child->getSku());
                        $this->dataPersistor->clear($child->getSku());
                    }
                }
                $response['cancel'] = 'You canceled the coupon code.';
                $this->dataPersistor->clear('coupon_code_' . $this->getQuoteId());
                $this->dataPersistor->clear('%_discount_amount_' . $this->getQuoteId());
                $this->dataPersistor->clear('coupon_code_' . $productSku);
                $this->dataPersistor->clear('product_price_' . $productSku);
                $this->dataPersistor->clear($productSku);
                $this->dataPersistor->clear('if_coupon_applied');
                $this->cacheClean();
            }
        } else {
            $couponCode = $this->getRequest()->getParam('coupon_code');
            $productPrice = (int)$this->getRequest()->getParam('productPrice');

            if (!empty($couponCode)) {
                if ($this->getCode($couponCode) == true) {
                    $fromDate = $this->getDiscountType($couponCode)[0]['from_date'];
                    $toDate = $this->getDiscountType($couponCode)[0]['to_date'];
                    $currentDate = date("Y-m-d");
                    if ($fromDate < $currentDate && $toDate > $currentDate || $fromDate < $currentDate && !$toDate || !$fromDate && !$toDate) {
                        if ($this->getDiscountType($couponCode)[0]['simple_action'] == 'by_percent') {
                            $response['simple_action'] = 'by_percent';
                        }
                        $allCategories = $this->getAllCategoryCollection();
                        foreach ($allCategories as $product) {

                            $this->dataPersistor->clear('coupon_code_' . $this->getQuoteId());
                            $this->dataPersistor->clear('%_discount_amount_' . $this->getQuoteId());
                            $this->dataPersistor->clear('coupon_code_' .  $product->getSku());
                            $this->dataPersistor->clear($product->getSku());
                        }

                        $product = $this->getProductDataUsingSku($productSku);
                        if ($product->getTypeId() == \Magento\ConfigurableProduct\Model\Product\Type\Configurable::TYPE_CODE) {
                            $response['productType'] = 'ConfigurableProduct';
                            $_children = $product->getTypeInstance()->getUsedProducts($product);
                            foreach ($_children as $child) {
                                $this->dataPersistor->set('coupon_code_' . $this->getQuoteId(), $couponCode);
                                $this->dataPersistor->set('%_discount_amount_' . $this->getQuoteId(), $this->getDiscountType($couponCode)[0]['discount_amount']);
                                $this->dataPersistor->set('coupon_code_' . $child->getSku(), $couponCode);
                                $this->dataPersistor->set('product_price_' . $child->getSku(), $originalPrice);
                                $response['productSku'] = $productSku;
                                $this->dataPersistor->set($child->getSku(), $child->getSku());
                            }
                        }
                        $this->customerSession->setRemoveProductFromMiniCart($productId);
                        $productInfo = $this->cart->getQuote()->getItemsCollection();
                        foreach ($productInfo as $item) {
                            if ($item->getProductId() == $productId) {
                                $response['update_items'] = 'true';
                                $response['item_id'] = $item->getData('item_id');
                                $response['item_qty'] = $item->getData('qty');
                            }
                        }


                        $categoryProducts = $this->getCategoryCollection($categoryId);
                        foreach ($categoryProducts as $product) {
                            $this->dataPersistor->set('coupon_code_' . $this->getQuoteId(), $couponCode);
                            $this->dataPersistor->set('%_discount_amount_' . $this->getQuoteId(), $this->getDiscountType($couponCode)[0]['discount_amount']);
                            $this->dataPersistor->set('coupon_code_' . $product->getSku(), $couponCode);
                            $this->dataPersistor->set($product->getSku(), $product->getSku());
                        }
                        $this->dataPersistor->set('coupon_code_' . $this->getQuoteId(), $couponCode);
                        $this->dataPersistor->set('%_discount_amount_' . $this->getQuoteId(), $this->getDiscountType($couponCode)[0]['discount_amount']);
                        $this->dataPersistor->set('coupon_code_' . $productSku, $couponCode);
                        $this->dataPersistor->set('product_price_' . $productSku, $originalPrice);

                        //$this->dataPersistor->set('categoryIds',$categoryIds );
                        $response['success'] = '<strong style="color:green">You used coupon code!</strong>';
                        $response['productSku'] = $productSku;
                        $response['discount_value'] = $this->getDiscountType($couponCode)[0]['discount_amount'];
                        $this->dataPersistor->set($productSku, $productSku);


                        $this->cacheClean();
                    } else {
                        $response['expire'] = '<strong style="color:#68202f">Your coupon code is Expire!</strong>';
                    }
                } else {
                    $response['error'] = '<strong style="color:red">Your coupon code is invalid!</strong>';
                    $this->cacheClean();
                }
            }
        }
        $result->setData($response);
        return $result;
    }

    public function getCode($couponCode)
    {
        $collection = $this->productRuleFactory->create();
        $collection->addFieldToFilter('status', 1)
            ->addFieldToFilter('coupon_code', $couponCode)
            ->addFieldToSelect('coupon_code');
        if ($collection->getData('coupon_code')) {
            return true;
        }
    }
    public function getProductDataUsingSku($productsku)
    {
        return $this->productrepository->get($productsku);
    }
    public function getDiscountType($couponCode)
    {
        $collection = $this->productRuleFactory->create();
        $collection->addFieldToFilter('status', 1)
            ->addFieldToFilter('coupon_code', $couponCode)
            ->addFieldToSelect('*');
        return $collection->getData('simple_action');
    }

    public function getProductQuote($product)
    {
        $quote = $this->_checkoutSession->getQuote();
        $cartItems = $quote->getItemByProduct($product);
        return $cartItems;
    }

    public function getCollection()
    {
        $collection = $this->productRuleFactory->create();
        $collection->addFieldToFilter('status', 1)
            ->addFieldToSelect('*');
        return $collection;
    }
    public function getDiscount()
    {
        $price = $this->getCollection()->getData('discount_amount');
        return $price[0]['discount_amount'];
    }



    public function getCategoryCollection($categoryId)
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addCategoriesFilter(['in' => $categoryId]);
        return $collection;
    }
    public function getAllCategoryCollection()
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        return $collection;
    }

    public function getCurrentCategory()
    {
        return $this->registry->registry('current_category');
    }

    public function getQuoteId(): int
    {
        return (int)$this->_checkoutSession->getQuote()->getId();
    }
    public function cacheClean()
    {
        $types = array('config', 'layout', 'block_html', 'collections', 'reflection', 'db_ddl', 'eav', 'config_integration', 'config_integration_api', 'full_page', 'translate', 'config_webservice');
        foreach ($types as $type) {
            $this->_cacheTypeList->cleanType($type);
        }
        foreach ($this->_cacheFrontendPool as $cacheFrontend) {
            $cacheFrontend->getBackend()->clean();
        }
    }
}
