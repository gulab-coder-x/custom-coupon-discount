<?php

namespace Kinex\ProductDiscount\Controller\Cart;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class ChildProduct extends Action
{
    protected $_productRepository;
    protected $_resultJsonFactory;
    protected $dataPersistor;
    public function __construct(
        Context $context,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
    ) {
        $this->_productRepository = $productRepository;
        $this->dataPersistor = $dataPersistor;
        $this->_resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $result = $this->_resultJsonFactory->create();
        $response = array(
            'special_price' => '',
            'regular_price' => '',
            'child_sku' => ''
        );
        //  $parentId = $this->getRequest()->getParam('parent_id');
        $childSku = $this->getRequest()->getParam('child_sku');
        $product = $this->_productRepository->get($childSku);
        if($product->getPrice()<$product->getData('price'))
        {
            $this->dataPersistor->set('child_sku_'.$childSku,$childSku);
            $response['special_price'] = $product->getPrice();
            $response['regular_price'] =$product->getData('price');
            $response['child_sku'] =$childSku;

        }
        $result->setData($response);
        return $result;
    }
}
