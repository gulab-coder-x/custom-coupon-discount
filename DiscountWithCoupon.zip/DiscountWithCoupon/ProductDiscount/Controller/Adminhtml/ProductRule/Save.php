<?php
namespace Kinex\ProductDiscount\Controller\Adminhtml\ProductRule;
use Magento\Backend\App\Action;
use Kinex\ProductDiscount\Model\ProductRuleFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;

    private $productRuleFactory;

    private $productRuleRepository;

    public function __construct(
        Action\Context $context,
        DataPersistorInterface $dataPersistor,
        ProductRuleFactory $productRuleFactory,
        \Kinex\ProductDiscount\Api\ProductRuleRepositoryInterface $productRuleRepository
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->productRuleFactory = $productRuleFactory;
        $this->productRuleRepository = $productRuleRepository;
        parent::__construct($context);
    }
	
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            if (isset($data['status']) && $data['status'] === 'true') {
                $data['status'] = ProductRule::STATUS_ENABLED;
            }
            if (empty($data['product_rule_id'])) {
                $data['product_rule_id'] = null;
            }

           
            $model = $this->productRuleFactory->create();

            $id = $this->getRequest()->getParam('product_rule_id');
            if ($id) {
                try {
                    $model = $this->productRuleRepository->getById($id);
                } catch (LocalizedException $e) {
                    $this->messageManager->addErrorMessage(__('This Rule no longer exists.'));
                    return $resultRedirect->setPath('*/*/');
                }
            }

            $model->setData($data);

            $this->_eventManager->dispatch(
                'productrule_prepare_save',
                ['productrule' => $model, 'request' => $this->getRequest()]
            );

            try {
                $this->productRuleRepository->save($model);
                $this->messageManager->addSuccessMessage(__('You saved the product rule.'));
                $this->dataPersistor->clear('productrule');
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['product_rule_id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addExceptionMessage($e->getPrevious() ?:$e);
            } catch (\Exception $e) {
                $this->messageManager->addExceptionMessage($e, __('Something went wrong while saving the product rule.'));
            }

            $this->dataPersistor->set('productrule', $data);
            return $resultRedirect->setPath('*/*/edit', ['product_rule_id' => $this->getRequest()->getParam('product_rule_id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
