<?php
namespace Kinex\ProductDiscount\Helper;

use Magento\Customer\Model\Session;
use Magento\Catalog\Model\CategoryFactory;

use function PHPUnit\Framework\returnSelf;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var Magento\Customer\Model\Session
     */
    protected $customerSession;

    protected $productRuleFactory;
    protected $categoryFactory;
    protected $dataPersistor;
    protected $objectManager;

    protected $_productFactory;
    protected $_productCollectionFactory;
    /**
     * Dependency Initilization
     *
     * @param Session $customerSession
     * @param \Magento\Framework\App\Helper\Context $context
     */
    public function __construct(
        Session $customerSession,
        CategoryFactory $categoryFactory,
        \Magento\Framework\App\Helper\Context $context,
        \Kinex\ProductDiscount\Model\ResourceModel\ProductRule\CollectionFactory $productRuleFactory,
        \Magento\Framework\App\Request\DataPersistorInterface $dataPersistor,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
        \Magento\Framework\ObjectManagerInterface $objectManager
    ) {
        $this->categoryFactory = $categoryFactory;
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->customerSession = $customerSession;
        $this->productRuleFactory = $productRuleFactory;
        $this->dataPersistor = $dataPersistor;
        $this->_productFactory = $productFactory;
        $this->objectManager = $objectManager;
        parent::__construct($context);
    }

    /**
     * Get Customer Id
     *
     * @return int
     */

    public function getCouponCollection($couponCode)
    {
        $collection = $this->productRuleFactory->create();
       $collection->addFieldToFilter('status', 1);
        $collection->addFieldToFilter('coupon_code',$couponCode);
        return $collection->getData();
    }

    
    public function dataPersistor()
    {
        return $this->dataPersistor;
    }

    public function getProduct($id)
    {
        return $this->_productFactory->create()->load($id);
    }

    public function getObjectManager()
    {
        return $this->objectManager;
    }
    
    public function getProductCollectionByCategories($couponCategory)
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addCategoriesFilter(['in' => $couponCategory]);
        return $collection;
    }

    public function getCategory($categoryId)
    {
        $category = $this->categoryFactory->create();
        $category->load($categoryId);
        return $category;
    }

   public function searchValueInArray($searchValue, $array) {
        foreach ($array as $key => $value) {
            if ($value === $searchValue) {
                return true;
            } elseif (is_array($value)) {
                // Recursively search in sub-arrays
                if ($this->searchValueInArray($searchValue, $value)) {
                    return true;
                }
            }
        }
        return false;
    }
}