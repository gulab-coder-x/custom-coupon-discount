var config = {
    config: {
        mixins: {
            'Magento_ConfigurableProduct/js/configurable': {
                'Kinex_ProductDiscount/js/model/skuswitch': true
            },
            'Magento_Swatches/js/swatch-renderer': {
                'Kinex_ProductDiscount/js/model/swatch-skuswitch': true
            }
        }
	}
};