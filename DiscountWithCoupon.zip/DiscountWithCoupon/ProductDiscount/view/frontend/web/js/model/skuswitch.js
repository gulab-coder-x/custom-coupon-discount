define([
    'jquery',
    'mage/utils/wrapper',
    'Magento_Catalog/js/price-utils'
], function ($, wrapper, priceUtils) {
    'use strict';

    return function (targetModule) {

        var reloadPrice = targetModule.prototype._reloadPrice;
        var reloadPriceWrapper = wrapper.wrap(reloadPrice, function (original) {
            var result = original();
            var simpleSku = this.options.spConfig.skus[this.simpleProduct];
            var simpleName = this.options.spConfig.names[this.simpleProduct];
            var customurl = "discountcode/cart/childproduct";
            if (simpleSku != '') {
                $('div.product-info-main .sku .value').html(simpleSku);
                $.ajax({
                    url: customurl,
                    data: {
                        child_sku: simpleSku,
                    },
                    type: "POST",
                    dataType: 'json'
                }).done(function (data) {
                    if (data.child_sku) {
                        console.log(data.child_sku);
                        console.log(data.special_price);
                        console.log(data.regular_price);
                        var price = priceUtils.formatPrice(data.regular_price);
                        if ($('#old-price-amount')) {
                            $('#old-price-amount').text(price);
                            var regular_price = data.regular_price;
                            var special_price =data.special_price;
                           var  discount =regular_price-special_price;
                            console.log(discount);
                            $('#discount-percent-amount').html(discount);
                        }
                    }

                }).fail(function () {
                    //console.log('failed');
                    //alert("Sorry. Server unavailable. ");
                })
            }
            if (simpleName != '') {
                $('div.product-info-main .page-title .base').html(simpleName);
            }
            return result;
        });
        targetModule.prototype._reloadPrice = reloadPriceWrapper;
        return targetModule;
    };
});